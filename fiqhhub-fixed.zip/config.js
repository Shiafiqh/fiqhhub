// FiqhHub Configuration
// Change API_URL to your deployed server URL (e.g. https://fiqhhub-api.onrender.com)
window.FIQHHUB_CONFIG = {
    API_URL: '',  // empty = same origin (works when served from proxy.js). Set to full URL for separate deployment
};
